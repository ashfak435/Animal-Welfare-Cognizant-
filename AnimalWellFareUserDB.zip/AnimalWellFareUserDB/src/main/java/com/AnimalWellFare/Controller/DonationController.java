package com.AnimalWellFare.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.AnimalWellFare.Entities.Donation;
import com.AnimalWellFare.Service.DonationService;
import com.AnimalWellFare.Service.EmailService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping
public class DonationController {

	@Autowired
	private DonationService donationService;

	@Autowired
	private EmailService emailService;

	@PostMapping("/saveDonation")
	public Donation saveDonation(@RequestBody Donation donation) {
		Donation donation2 = donationService.createDonation(donation);
		
//		capitalizing the name
		String firstLetStr = donation.getDonorName().substring(0, 1);
		String remLetStr = donation.getDonorName().substring(1);
		firstLetStr = firstLetStr.toUpperCase();
		String firstLetterCapitalizedName = firstLetStr + remLetStr;
		
//		sending email	
		emailService.sendEmail(donation.getDonorDate(), "Thank you from AWC",
				"Dear " + firstLetterCapitalizedName + ",\nThank you for your generous gift to AWC of ₹"
						+ donation.getDonorAmount().toString() + ". " + "We are thrilled to have your support. "
						+ "Through your donation we have been able to accomplish our goal "
						+ "and continue working towards.");
		
		
		return donation2;
	}

	@GetMapping("/getAllDonation")
	public Iterable<Donation> getAllDonation() {
		return donationService.findAllDonation();
	}
}
