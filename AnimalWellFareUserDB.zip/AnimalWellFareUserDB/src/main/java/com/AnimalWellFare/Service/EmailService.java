package com.AnimalWellFare.Service;

public interface EmailService {
	public void sendEmail(String toEmail,String subject,String body);
}
