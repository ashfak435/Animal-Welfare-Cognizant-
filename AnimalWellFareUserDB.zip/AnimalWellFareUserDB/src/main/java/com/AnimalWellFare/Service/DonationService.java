package com.AnimalWellFare.Service;

import com.AnimalWellFare.Entities.Donation;

public interface DonationService {
	Donation createDonation(Donation donation);
	Iterable<Donation> findAllDonation();
}
