package com.AnimalWellFare.Service;

import com.AnimalWellFare.Entities.Contact;

public interface ContactService {
	Contact createContact(Contact contact);
	Iterable<Contact> findAllContact();
	Contact findContactById(String id);
	void deleteContact(String id);
}
