package com.AnimalWellFare.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AnimalWellFare.Entities.Contact;
import com.AnimalWellFare.Repo.ContactRepo;
@Service
public class ContactServiceImpl implements ContactService {
	@Autowired
	ContactRepo contactRepo;

	@Override
	public Contact createContact(Contact contact) {
		Contact save = contactRepo.save(contact);
		return save;
	}

	@Override
	public Iterable<Contact> findAllContact() {
		return contactRepo.findAll();
	}

	@Override
	public Contact findContactById(String id) {
		Optional<Contact> optional = contactRepo.findById(id);
		return optional.get();
	}

	@Override
	public void deleteContact(String id) {
		contactRepo.deleteById(id);
	}

}
