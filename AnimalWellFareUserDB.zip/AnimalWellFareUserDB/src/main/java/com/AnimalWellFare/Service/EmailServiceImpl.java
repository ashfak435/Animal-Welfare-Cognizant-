package com.AnimalWellFare.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
@Service
public class EmailServiceImpl implements EmailService {
	
	@Autowired
	private JavaMailSender javaMailSender;
	@Override
	public void sendEmail(String toEmail, String subject, String body) {
		SimpleMailMessage mailMessage=new SimpleMailMessage();
		mailMessage.setFrom("ashfak987ali@gmail.com");
		mailMessage.setTo(toEmail);
		mailMessage.setText(body);
		mailMessage.setSubject(subject);
		javaMailSender.send(mailMessage);
	}

}
