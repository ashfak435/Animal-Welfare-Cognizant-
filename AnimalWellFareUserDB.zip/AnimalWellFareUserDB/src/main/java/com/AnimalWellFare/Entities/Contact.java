package com.AnimalWellFare.Entities;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Contact {
	private String cName;
	@Id
	private String cEmail;
	private String cMessege;
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getcEmail() {
		return cEmail;
	}
	public void setcEmail(String cEmail) {
		this.cEmail = cEmail;
	}
	public String getcMessege() {
		return cMessege;
	}
	public void setcMessege(String cMessege) {
		this.cMessege = cMessege;
	}
}
