package com.AnimalWellFare.Admin.controller;

import com.AnimalWellFare.Admin.entity.Contact;
import com.AnimalWellFare.Admin.entity.User;
import com.AnimalWellFare.Admin.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

@RestController
@RequestMapping
public class UserController {

    @Autowired
    private UserService userService;
    
    @Autowired
    private RestTemplate restTemplate;

    @PostConstruct
    public void initRoleAndUser() {
        userService.initRoleAndUser();
    }

    @PostMapping({"/registerNewUser"})
    public User registerNewUser(@RequestBody User user) {
        return userService.registerNewUser(user);
    }

    @GetMapping({"/forAdmin"})
    @PreAuthorize("hasRole('Admin')")
    public String forAdmin(){
        return "This URL is only accessible to the admin";
    }
    @GetMapping({"/getAllContact"})
    @PreAuthorize("hasRole('Admin')")
    public Iterable<Contact> getAllContact()
    {
    	return this.restTemplate.getForObject("http://localhost:9091/getContact", Iterable.class);
    }
    @GetMapping({"/getDonationDetails"})
    @PreAuthorize("hasRole('Admin')")
    public Iterable<Contact> getDonationDetails()
    {
    	return this.restTemplate.getForObject("http://localhost:9091/getAllDonation", Iterable.class);
    }
    @DeleteMapping({"/deleteContactById/{id}"})
    @PreAuthorize("hasRole('Admin')")
    public ResponseEntity<Map<String, Boolean>> deleteContactById(@PathVariable String id)
    {
    	
    	this.restTemplate.delete("http://localhost:9091/deleteContact/"+id);
    	Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        
    	return ResponseEntity.ok(response);
    }
}
