package com.AnimalWellFare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnimalWellFareUserDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
