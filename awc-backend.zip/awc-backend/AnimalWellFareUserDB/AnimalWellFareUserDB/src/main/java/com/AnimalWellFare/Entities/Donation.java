package com.AnimalWellFare.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Donation {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String donorName;
	private Integer donorAmount;
	private String donorDate;
	private String donorMessage;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDonorName() {
		return donorName;
	}
	public void setDonorName(String donorName) {
		this.donorName = donorName;
	}
	public Integer getDonorAmount() {
		return donorAmount;
	}
	public void setDonorAmount(Integer donorAmount) {
		this.donorAmount = donorAmount;
	}
	public String getDonorDate() {
		return donorDate;
	}
	public void setDonorDate(String donorDate) {
		this.donorDate = donorDate;
	}
	public String getDonorMessage() {
		return donorMessage;
	}
	public void setDonorMessage(String donorMessage) {
		this.donorMessage = donorMessage;
	}
}
