package com.AnimalWellFare.Repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.AnimalWellFare.Entities.Donation;
@Repository
public interface DonationRepo extends CrudRepository<Donation, Integer>{

}
