package com.AnimalWellFare.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AnimalWellFare.Entities.Donation;
import com.AnimalWellFare.Repo.DonationRepo;
@Service
public class DonationServiceImpl implements DonationService {
	@Autowired
	DonationRepo donationRepo;
	@Override
	public Donation createDonation(Donation donation) {
		return donationRepo.save(donation);
	}
	@Override
	public Iterable<Donation> findAllDonation() {
		return donationRepo.findAll();
	}

}
