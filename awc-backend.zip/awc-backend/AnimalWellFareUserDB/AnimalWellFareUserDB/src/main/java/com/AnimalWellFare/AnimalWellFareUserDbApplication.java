package com.AnimalWellFare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnimalWellFareUserDbApplication {
	public static void main(String[] args) {
		SpringApplication.run(AnimalWellFareUserDbApplication.class, args);
	}
}
