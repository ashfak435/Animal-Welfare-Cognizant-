import React from 'react';
import './App.css';
import {
  BrowserRouter as Router,
  Route,
  Routes
} from "react-router-dom";
import Header from './components/Header';
import Home from './components/Home';
import About from './components/About';

import Contact from './components/Contact';
import Footer from './components/Footer';
import Login from './components/Login';
import Adminlogin from './components/AdminLogin';
import Signup from './components/Signup';
import ContactTable from './components/ContactTable';
import DonateUs from './components/DonateUs';
import Error404 from './components/Error404';
import DonationTable from './components/DonationTable';
import Team from './components/Team';



function App() {
  return (
    <>
      <h1><center><b>Animal Welfare Cognizant</b></center></h1>
      <Router>
        <div>

          <Header />

          <Routes>
            <Route exact path="/home" element={<Home />} />


            <Route exact path="/login" element={<Login />} />


            <Route exact path="/signup" element={<Signup />} />



            <Route exact path="/home/:name" element={<Home />} />


            <Route exact path="/about" element={<About />} />


            <Route exact path="/viewdonation" element={<DonationTable />} />


            <Route exact path="/contact" element={<Contact />} />


            <Route exact path="/contacttable" element={<ContactTable />} />


            <Route exact path="/donateus" element={<DonateUs />} />



            <Route exact path="/team" element={<Team />} />


            <Route exact path="/adminlogin" element={<Adminlogin />} />


            <Route exact path="/" element={<Home />} />

            <Route path="*" element={<Error404/>} />
          </Routes>

          <Footer />
        </div>
      </Router>
    </>
  );
}


export default App;
