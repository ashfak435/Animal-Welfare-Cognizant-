import React from "react";

export default function Footer() {
    return (
        <>
            <footer className="text-center text-lg-start bg-dark text-white">
                <div className="container text-center text-md-left">
                    <div className="row text-center text-md-left">
                        <div className="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
                            <h5 className=" text-uppercase mb-4 font-weight-bold text-warning text-white">Animal Welfare Cognizant</h5>
                            <p>Animal Welfare Cognizant is developed as a POD project under Cognizant GenC Training.
                            </p>
                        </div>


                        <div className="col-md-4 col-lg-3 col-xl-2 mx-auto mt-3">
                            <h5 className=" text-uppercase mb-4 font-weight-bold text-warning text-white">Support</h5>
                            <p>
                                <i className="bi bi-house-heart-fill mr-3"></i> Adopt
                            </p>
                            <p>
                                <i className="bi bi-bandaid mr-3"></i>  Foster
                            </p>
                            <p>
                                <i className="bi bi-balloon-heart mr-3"></i> Donate
                            </p>
                        </div>
                        <div className="col-md-4 col-lg-3 col-xl-2 mx-auto mt-3">
                            <h5 className=" text-uppercase mb-4 font-weight-bold text-warning text-white">Team</h5>
                            <p>
                                <i>Utkarsh R, Snehil B</i>
                            </p>
                            <p>
                                <i>Amit R, Ashfaque A</i>
                            </p>
                            <p>
                                <i>Utkarsh K, Rahul B</i>
                            </p>

                        </div>
                        <div className="col-md-4 col-lg-3 col-xl-2 mx-auto mt-3">
                            <h5 className=" text-uppercase mb-4 font-weight-bold text-warning text-white">Contact</h5>
                            <p>
                                <i className="bi bi-house-door mr-3"></i> Pune, Maharashtra, India
                            </p>
                            <p>
                                <i className="bi bi-envelope mr-3"></i>  support@awc.com
                            </p>
                            <p>
                                <i className="bi bi-telephone mr-3"></i>+91 XXXXXXXXXX
                            </p>
                        </div>
                    </div>
                    <hr className="mb-4" />
                    <div className="row align-items-center">
                        <div className="col-md-7 col-lg-8">
                            <p>Copyright @2022 All rights reserved by:
                                <a href="/" style={{ textDecoration: "none" }}>
                                    <strong className="me-2 text-white"> AWC</strong>
                                </a>
                            </p>
                        </div>
                        <div className="col-md-5 col-lg-4">
                            <div className="text-center text-md-right">
                                <ul className="list-unstyled list-inline">
                                    <li className="list-inline-item">
                                        <a href="/" className="btn-floating btn-sm text-white" style={{ fontSize: "23px" }}><i className="bi bi-facebook"></i></a>
                                    </li>
                                    <li className="list-inline-item">
                                        <a href="/" className="btn-floating btn-sm text-white" style={{ fontSize: "23px" }}><i className="bi bi-twitter"></i></a>
                                    </li>
                                    <li className="list-inline-item">
                                        <a href="https://www.google.com/" className="btn-floating btn-sm text-white" style={{ fontSize: "23px" }}><i className="bi bi-google"></i></a>
                                    </li>
                                    <li className="list-inline-item">
                                        <a href="/" className="btn-floating btn-sm text-white" style={{ fontSize: "23px" }}><i className="bi bi-instagram"></i></a>
                                    </li>
                                    <li className="list-inline-item">
                                        <a href="/" className="btn-floating btn-sm text-white" style={{ fontSize: "23px" }}><i className="bi bi-linkedin"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </>
    )
}