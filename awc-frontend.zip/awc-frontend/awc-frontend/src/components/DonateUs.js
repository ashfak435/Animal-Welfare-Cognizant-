import React, { useState } from 'react';
import { useFormik } from "formik";
import AddressService from '../service/AddressService';
import { ToastContainer, toast } from "react-toastify";
import donateimage from "../images/donation.svg";
import "react-toastify/dist/ReactToastify.css";
export default function DonateUs() {

  const [disable, setDisable] = useState(true);

  const donate = (values) => {
    try {
      setDisable(true);

      let datas = { donorName: values.donorName, donorAmount: values.donorAmount, donorDate: values.donorDate, donorMessage: values.donorMessage };
      AddressService.createDonation(datas).then(res => {

        if (!res.data.donorDate) {
          toast.error(`🎃 Something went wrong 🎃`, {
            position: "top-center",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          });
        } else {
          toast.success(`✨Donation Sent Successfully✨`, {
            position: "top-center",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          });
          toast.success(`Check your email...📧`, {
            position: "top-center",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          });



        }


      })
      setDisable(false);

    } catch (error) {

      toast.warn(`🎃 Server not running 🎃`, {
        position: "top-center",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
      setDisable(false);

    }
  }


  const validate = (values) => {
    let errors = {};

    if (values.donorName.length === 0) {
      errors.donorName = "Full Name should not be empty";
    } else if (values.donorName.length > 0 && values.donorName.length < 3) {
      errors.donorName = `Full Name must be at least three characters`;
    }

    if (values.donorDate.length === 0) {
      errors.donorDate = "Email should not be empty";
    } else if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.donorDate) &&
      values.donorDate.length > 0
    ) {
      errors.donorDate = `Email is not valid`;
    }

    if (values.donorAmount.length === 0) {
      errors.donorAmount = "Please enter some money";
    }
    else if (values.donorAmount === 0) {
      errors.donorAmount = "Enter Amount greater than 0 rupees";
    }


    if (errors.donorName || errors.donorAmount || errors.donorDate) {
      setDisable(true);
    } else {
      setDisable(false);
    }
    return errors;
  };

  const formik = useFormik({
    initialValues: {
      donorName: "",
      donorDate: "",
      donorAmount: "",
      donorMessage: ""
    },
    validate,
    onSubmit(values) {
      donate(values);
      formik.resetForm();
    },
  });

  return (
    <div className="container mb-5">
      <div className="row">
        <div className="col-12 text-center py-2 my-4">
          <h2>Donate Us</h2>
          <hr />
        </div>
      </div>
      <div className="row">
        <div className="col-md 5 register-donation">
          <br></br>
          <img src={donateimage} alt="Donate Us" height={400} width={400} />
        </div>
        <div className="col-md-6">
          <form onSubmit={formik.handleSubmit} autoComplete="off">
            <div className='from-group'>
              <label><h4>Enter Your Name</h4></label>
              <input type="text" placeholder='Full Name' name="donorName" required className='form-control' onChange={formik.handleChange} onBlur={formik.handleBlur} value={formik.values.donorName} />
              {formik.touched.donorName && formik.errors.donorName ? (
                <div className="error">{formik.errors.donorName}</div>
              ) : null}
            </div>
            <div className='from-group'>
              <label><h4>Enter The Amount</h4></label>
              <input type="number" placeholder='Rs.' name="donorAmount" required className='form-control' onChange={formik.handleChange} onBlur={formik.handleBlur} value={formik.values.donorAmount}></input>
            </div>
            {formik.touched.donorAmount && formik.errors.donorAmount ? (
              <div className="error">{formik.errors.donorAmount}</div>
            ) : null}
            <div className='from-group'>
              <label><h4>Enter Your Email</h4></label>
              <input
                placeholder="Enter Email"
                name="donorDate"
                type="email"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.donorDate}
                required
                className='form-control'
                id="date"
              ></input>

              {formik.touched.donorDate && formik.errors.donorDate ? (
                <div className="error">{formik.errors.donorDate}</div>
              ) : null}

            </div>
            <div className='from-group'>
              <label><h4>Enter The Message</h4></label>
              <textarea type="text" placeholder='Enter Your Message' name="donorMessage" className='form-control' onChange={formik.handleChange} onBlur={formik.handleBlur} value={formik.values.donorMessage}></textarea>

            </div>
            <button type="submit" disabled={disable} className='btn btn-dark mt-3 mr-5 m-2' >Submit</button>
          </form>
        </div>
      </div>
      <ToastContainer />
    </div>
  )


}