import React from "react";
import { useNavigate } from 'react-router-dom';
import Error404 from "../images/404.svg";

export default function  Error ()  {
    let navigate = useNavigate();

  return (
    <>
      <div className="success-verified-body">
  
        <div className="main-content-success-verify">
          <div className="container-fluid">
            <div className=" register-error text-center mx-auto my-auto">
              <img src={Error404} alt="" height="305" width="305" />
              <div className="text-center success-verified-header mt-0">
                Oops! Page Not Found
              </div>

              <div className="success-email-button  mx-auto mt-2 mb-5 col-md-5">
                <button
                  type="submit"
                  name="success-verified"
                  id="success-verified"
                  onClick={() => navigate("/")}
                  className="btn btn-lg btn-block btn-dark"
                >
                  <div className="verified-button-text">
                    <span>Go to Home Page</span>
                    <span className="arrow-verified"></span>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>
   
      </div>
    </>
  );
};

