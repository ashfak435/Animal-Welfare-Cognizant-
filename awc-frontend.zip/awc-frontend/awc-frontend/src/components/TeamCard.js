import React from 'react';

const TeamCard = (props) => {
    return (
        <>
            <div className="col-xs-12 col-sm-6 col-md-3">
                <div className="image-flip" >
                    <div className="mainflip flip-0">
                        <div className="frontside">
                            <div className="card">
                                <div className="card-body text-center">
                                    <p><img src={props.image} alt="card" /></p>
                                    <h4 className="card-title">{props.name}</h4>
                                    <p className="card-text">{props.position}</p>
                                    <a href="https://www.fiverr.com/share/qb8D02" className="btn btn-primary btn-sm">More Info</a>
                                </div>
                            </div>
                        </div>
                        <div className="backside">
                            <div className="card">
                                <div className="card-body text-center mt-4">
                                    <h4 className="card-title">{props.name}</h4>
                                    <p className="card-text"> Well aware of their key responsibility areas And to protect piracy for the user.</p>
                                    <ul className="list-inline">
                                        <li className="list-inline-item">
                                            <a className="social-icon text-xs-center" target="_blank" rel="noreferrer" href="https://www.fiverr.com/share/qb8D02">
                                                <i className="fa fa-facebook"></i>
                                            </a>
                                        </li>
                                        <li className="list-inline-item">
                                            <a className="social-icon text-xs-center" target="_blank" rel="noreferrer" href="https://www.fiverr.com/share/qb8D02">
                                                <i className="fa fa-twitter"></i>
                                            </a>
                                        </li>
                                        <li className="list-inline-item">
                                            <a className="social-icon text-xs-center" target="_blank" rel="noreferrer" href="https://www.fiverr.com/share/qb8D02">
                                                <i className="fa fa-skype"></i>
                                            </a>
                                        </li>
                                        <li className="list-inline-item">
                                            <a className="social-icon text-xs-center" target="_blank" rel="noreferrer" href="https://www.fiverr.com/share/qb8D02">
                                                <i className="fa fa-google"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );


}

export default TeamCard;
