import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
export default function DonationTable() {

  const [donations, setDonations] = useState([]);
  let navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('jwtToken');

    if(!token){
      navigate("/adminlogin");
  }

    axios.get('http://localhost:9090/getDonationDetails', { headers: { "Authorization": `Bearer ${token}` } })
      .then(res => {
        setDonations(res.data);
      })
      .catch((error) => {
        console.log(error)
      });
  }, []);





  return (

    <div>
      <h2 class="margin-sm text-center">Donor Details</h2>
      <div class="card margin-op">
        <table className="table table-hover">
          <thead class="thead">
            <tr>

              <th scope="col">
                <h4>Name</h4>
              </th>
              <th scope="col">
                <h4>Amount</h4>
              </th>
              <th scope="col">
                <h4>Email</h4>
              </th>
              <th scope="col">
                <h4>Message</h4>
              </th>

            </tr>
          </thead>
          <tbody>
            {donations.map((prod) => (
              <tr>
                <td>{prod.donorName}</td>
                <td>{prod.donorAmount}</td>
                <td>{prod.donorDate}</td>
                <td>{prod.donorMessage}</td>

              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>




  )
}