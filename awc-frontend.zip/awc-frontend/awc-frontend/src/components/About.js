import React from "react";

import { NavLink } from "react-router-dom";

export default function About() {
    return (
        <div>
            <div className="container py-5 my-5">
                <div className="row">
                    <div className="col-md-6">
                        <h1 className="text-primary fw-bold mb-4 text-black">About Us</h1>
                        <p className="lead mb-4">
                            Animal Welfare Organisation
                            <p class="card-text" >Our mission is to create a better world for animals</p>
                            <p class="card-text" >We end the needless suffering of animals</p>
                            <p class="card-text" >We influence decision makers to put animals on the global agenda</p>
                            <p class="card-text" >We help the world see how important animals are to all of us</p>
                            <p class="card-text" >We inspire people to change animals’ lives for the better</p>
                            <p class="card-text" >We move the world to protect animals</p>
                        </p>

                        <NavLink to="/contact" className="btn btn-dark">Contact Us</NavLink>
                    </div>
                    <div className="col-md-6 d-flex justify-content-center">
                        <img src="/assets/images/bg.jpg" alt="About Us" height="400px" width="500px" />
                    </div>
                </div>
            </div>
        </div>
    )
}