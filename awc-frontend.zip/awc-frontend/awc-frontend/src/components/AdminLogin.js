import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import loginImage from "../images/login.svg";
import AddressService from '../service/AddressService';
import axios from 'axios';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export default function AdminLogin() {
    let navigate = useNavigate();
    const [adminLogin, setAdminLogin] = useState({
        userName: "",
        userPassword: ""
    });
    const handleInput = (e) => {
        const name = e.target.name;
        const value = e.target.value;
        setAdminLogin({ ...adminLogin, [name]: value });
    }
    const login = (event) => {
        event.preventDefault();
        let datas = { userName: adminLogin.userName, userPassword: adminLogin.userPassword };
        try {

            const respons = AddressService.createLogin(datas).then(res => {
                //Store userToken detail in localStorage

                localStorage.setItem('jwtToken', res.data.jwtToken);
                //Store userDetail in localStorage
                localStorage.setItem("id", JSON.stringify(res.data.user));
                localStorage.setItem("admin", JSON.stringify(res.data.user.userName));
                const config = {
                    headers: {
                        Authorization: 'Bearer ' + localStorage.getItem('jwtToken')
                    }
                };

                axios.get('http://localhost:9090/forAdmin', config).then(
                    response => {
                        //alert(response.data);
                        // this.state = ({ userData: response.data})
                        navigate("/home");
                    }
                )
            })
        } catch (error) {


            toast.error(`🎃Check you username or password and try again🎃`, {
                position: "top-center",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: false,
                progress: undefined,
            });


        }


    }
    return (
        <>

            <div className='container-fluid' style={{ marginTop: "56px" }}>
                <center><h3>ADMIN LOGIN</h3></center>
                <hr />
                <div className='row'>
                    <div className='col-md-6 p-0 register-login'>

                        <img src={loginImage} style={{ width: "100%", height: "300px" }} alt="Login" />

                        {/* <img src="/assets/images/pet1.jpg" style={{ width: "100%", height: "300px" }} alt="Login"></img> */}
                    </div>
                    <div className='col-md-6 '>
                        <form>
                            <div className='from-group'>
                                <label><h4>Username</h4></label>
                                <input type="text" placeholder='Username' name="userName" required className='form-control' onChange={handleInput} value={adminLogin.userName} />

                            </div>
                            <div className='from-group'>
                                <label><h4>Password</h4></label>
                                <input type="password" placeholder='Password' name="userPassword" required className='form-control' onChange={handleInput} value={adminLogin.userPassword}></input>
                            </div>
                            <div>
                                <button type="button" className='btn btn-dark mt-3 mr-5 m-2' onClick={login}>Submit</button>

                            </div>
                        </form>
                    </div>
                </div>
                <ToastContainer />
            </div>
        </>
    );

}