import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import Team from './Team';
import { CardText,CardSubtitle,CardTitle,CardBody,CardImg,CardGroup,Card} from 'reactstrap';


export default function Home() {
  return (
    <>
      <div
        id="carouselExampleIndicators"
        className="carousel slide"
        data-bs-ride="carousel"
      >
        <div className="carousel-indicators">
          <button
            type="button"
            data-bs-target="#carouselExampleIndicators"
            data-bs-slide-to="0"
            className="active"
            aria-current="true"
            aria-label="Slide 1"
          ></button>
          <button
            type="button"
            data-bs-target="#carouselExampleIndicators"
            data-bs-slide-to="1"
            aria-label="Slide 2"
          ></button>
          <button
            type="button"
            data-bs-target="#carouselExampleIndicators"
            data-bs-slide-to="2"
            aria-label="Slide 3"
          ></button>
        </div>
        <div className="carousel-inner">
          <div className="carousel-item active">
            <img
              src="/assets/images/home/caraousel1.jpg"
              className="d-block w-100"
              height={550}
              alt="First Slide"
            />
          </div>
          <div className="carousel-item">
            <img
              src="/assets/images/home/caraousel2.jpg"
              className="d-block w-100"
              height={550}
              alt="Second Slide"
            />
          </div>
          <div className="carousel-item">
            <img
              src="/assets/images/home/caraousel.jpg"
              className="d-block w-100"
              height={550}
              alt="Third Slide"
            />
          </div>
        </div>
        <button
          className="carousel-control-prev"
          type="button"
          data-bs-target="#carouselExampleIndicators"
          data-bs-slide="prev"
        >
          <span
            className="carousel-control-prev-icon"
            aria-hidden="true"
          ></span>
          <span className="visually-hidden">Previous</span>
        </button>
        <button
          className="carousel-control-next"
          type="button"
          data-bs-target="#carouselExampleIndicators"
          data-bs-slide="next"
        >
          <span
            className="carousel-control-next-icon"
            aria-hidden="true"
          ></span>
          <span className="visually-hidden">Next</span>
        </button>
      </div>

     <br></br>
     <CardGroup>
        <Card>
          <CardImg
            alt="Card image cap"
            src="/assets/images/pet1.jpg"
            top
            width="100%"
          />
          <CardBody>
            <CardTitle tag="h5">Pet Donations</CardTitle>
            
            <CardText>
              Love Animals? You can show your support by making an online donations or making a pet donations for AWC initiatives that look after hundreds of dogs and cats.
            </CardText>
            
          </CardBody>
        </Card>
        <Card className="col px-md-4">
          <CardImg
            alt="Card image cap"
            src="/assets/images/adopt1.jpg"
            top
            width="100%"
          />
          <CardBody>
            <CardTitle tag="h5">Adopt Animals</CardTitle>
            
            <CardText>
              Adopt a dog or cat near you instead buying a pet. Adopting a pet can be challenge we made it easy for you. Free pet Adoption near you in India.
            </CardText>
            
          </CardBody>
        </Card>
        <Card>
          <CardImg
            alt="Card image cap"
            src="/assets/images/cruelty1.jpg"
            top
            width="100%"
          />
          <CardBody>
            <CardTitle tag="h5">Voice for Voiceless</CardTitle>
            
            <CardText>
              Animal Cruelty is the evidence that our society is far from compassion. These acts against animals are not the problem but a symptom of our lack of evolvement and understanding.
            </CardText>
            
          </CardBody>
        </Card>
        
      </CardGroup>

     
    <br></br>
 
    </>
  );
}
