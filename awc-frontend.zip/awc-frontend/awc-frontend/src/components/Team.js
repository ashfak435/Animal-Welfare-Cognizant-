import React from 'react';
import TeamCard from './TeamCard';

import pp1 from "../images/ar.jpg";
import pp2 from "../images/aa.jpg";
import pp3 from "../images/rahul.png";
import pp4 from "../images/sb.jpg";
import pp5 from "../images/uk.jpg";
import pp6 from "../images/ur.jpg";
import "./Team.css";

const Team = () => {

    return (
        <>
            <section id="team" className="pb-5">
                <div className="container">
                    <div className="section-title h1">OUR TEAM</div>
                    <div className="row">
                        <TeamCard image={pp1} name="  Amit    Rai    " position="Frontend Developer" />
                        <TeamCard image={pp2} name="Ashfaque Ahmed" position="Backend Developer" />
                        <TeamCard image={pp3} name="Rahul Basrani" position="Frontend Developer" />
                        <TeamCard image={pp4} name="Snehil Bawgi" position="Backend Developer" />
                        <TeamCard image={pp5} name="Utkarsh Kumar" position="Backend Developer" />
                        <TeamCard image={pp6} name="Utkarsh Rai" position="Frontend Developer" />
                    </div>
                </div>
            </section>
        </>
    )
}

export default Team;