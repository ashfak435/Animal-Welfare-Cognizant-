import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
export default function ContactTable() {

  const [contacts, setContacts] = useState([]);
  let navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('jwtToken');

    if(!token){
        navigate("/adminlogin");
    }

    axios.get('http://localhost:9090/getAllContact', { headers: { "Authorization": `Bearer ${token}` } })
      .then(res => {
        setContacts(res.data);
      })
      .catch((error) => {
      });
  }, []);




  const deleteItem = (i) => {
    const token = localStorage.getItem('jwtToken');
    const email = contacts[i].cEmail;
    axios.delete(`http://localhost:9090/deleteContactById/${email}`, { headers: { "Authorization": `Bearer ${token}` } })
      .then(res => {
        window.location.reload(false);
      })
      .catch((error) => {
        console.log(error);
      });

  }


  return (

    <div>
      <h2 class="margin-sm text-center">Contact Details</h2>
      <div class="card margin-op">
        <table className="table table-hover">
          <thead>
            <tr>
              <th scope="col">
                <h4>Name</h4>
              </th>
              <th scope="col">
                <h4>Email</h4>
              </th>
              <th scope="col">
                <h4> Message</h4>
              </th>
            </tr>
          </thead>
          <tbody>
            {contacts.map((prod, index) => (
              <tr>

                <td>{prod.cName}</td>
                <td>{prod.cEmail}</td>
                <td>{prod.cMessege}</td>
                <td><i className='fa fa-trash' onClick={() => deleteItem(index)}></i></td>
              </tr>
            ))}
          </tbody>
        </table></div>
    </div>




  )
}