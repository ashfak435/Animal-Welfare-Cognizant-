import React, { useState } from 'react';
import { useFormik } from "formik";
import AddressService from '../service/AddressService';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import contactimage from "../images/contact.svg";


export default function Contact() {

  const [disable, setDisable] = useState(true);
  const contactUs = (values) => {
    try {
      setDisable(true);

      let datas = { cName: values.cName, cEmail: values.cEmail, cMessege: values.cMessege };


      AddressService.createContactUs(datas).then(res => {

        if (!res.data.cName) {
          toast.error(`🎃 Something went wrong 🎃`, {
            position: "top-center",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          });
        } else {
          toast.success(`✨Your query sent to admin✨`, {
            position: "top-center",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          });
          toast.success(`Check your email...📧`, {
            position: "top-center",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          });
        }
      })
      setDisable(false);
    } catch (error) {
      toast.warn(`🎃 Server not running 🎃`, {
        position: "top-center",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
      setDisable(false);
    }
  }

  const validate = (values) => {
    let errors = {};
    if (values.cName.length === 0) {
      errors.cName = "Full Name should not be empty";
    } else if (values.cName.length > 0 && values.cName.length < 3) {
      errors.cName = `Full Name must be at least three characters`;
    }

    if (values.cMessege.length === 0) {
      errors.cMessege = "Message should not be empty";
    }

    if (values.cEmail.length === 0) {
      errors.cEmail = "Email should not be empty";
    } else if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.cEmail) &&
      values.cEmail.length > 0
    ) {
      errors.cEmail = `Email is not valid`;
    }

    if (errors.cName || errors.cEmail || errors.cMessege) {
      setDisable(true);
    } else {
      setDisable(false);
    }
    return errors;
  };

  const formik = useFormik({
    initialValues: {
      cName: "",
      cEmail: "",
      cMessege: ""
    },
    validate,
    onSubmit(values) {
      contactUs(values);
      formik.resetForm();
    },
  });


  return (
    <div className="container mb-5">
      <div className="row">
        <div className="col-12 text-center py-2 my-4">

          <h2>Contact Us</h2>
          <hr />
        </div>
      </div>
      <div className="row">
        <div className="col-md 5 register-left">
          <br></br>
          <img src={contactimage} alt="Contact Us" height={300} width={400} />
          {/* <img src="/assets/images/cont.jpg" alt="Contact Us" height={300} width={400} /> */}
        </div>
        <div className="col-md-6">
          <form onSubmit={formik.handleSubmit} autoComplete="off">
            <div className='from-group'>
              <label><h4>Enter Your Name</h4></label>
              <input type="text" placeholder='Full Name' name="cName" required className='form-control' onChange={formik.handleChange} onBlur={formik.handleBlur} value={formik.values.cName} />
              {formik.touched.cName && formik.errors.cName ? (
                <div className="error">{formik.errors.cName}</div>
              ) : null}
            </div>
            <div className='from-group'>
              <label><h4>Email Address</h4></label>
              <input type="email" placeholder='Enter your email' name="cEmail" required className='form-control' onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.cEmail}></input>
              {formik.touched.cEmail && formik.errors.cEmail ? (
                <div className="error">{formik.errors.cEmail}</div>
              ) : null}
            </div>

            <div className='from-group'>
              <label><h4>Enter The Message</h4></label>
              <textarea type="text" placeholder='Enter text...' name="cMessege" required className='form-control' onChange={formik.handleChange} onBlur={formik.handleBlur} value={formik.values.cMessege}></textarea>
              {formik.touched.cMessege && formik.errors.cMessege ? (
                <div className="error">{formik.errors.cMessege}</div>
              ) : null}
              <div>
                <button type="submit" disabled={disable} className='btn btn-dark mt-3 mr-5 m-2' >Submit</button>

              </div>
            </div>
          </form>
        </div>
      </div>
      <ToastContainer />
    </div>
  )
}