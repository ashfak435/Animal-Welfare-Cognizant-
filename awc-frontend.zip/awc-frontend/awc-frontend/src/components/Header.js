import React from 'react'
import { NavLink } from "react-router-dom";

import { Link, useNavigate } from "react-router-dom";


export default function Header() {

  let admin = JSON.parse(localStorage.getItem("admin"));

  let navigate = useNavigate();
  const Logout = () => {
    localStorage.clear();
    navigate("/home");
  };

  if (admin) {
    return (
      <nav className="navbar navbar-expand-lg sticky-top navbar-light bg-dark text-white">
        <div className="container-fluid py-2">
          <NavLink
            className="navbar-brand mx-auto fw-bold me-2 text-white"
            to="/home"
          >
            <b><i><span style={{ color: "white" }}>AWC</span></i></b>
          </NavLink>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <Link
                  className="nav-link active text-white"
                  aria-current="page"
                  to="/home"
                >
                  Home
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-white" to="/team">
                  Our Team
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-white" to="/contacttable">
                  See Contacts
                </Link>
              </li>

              <li className="nav-item">
                <Link className="nav-link text-white" to="/viewdonation">
                  See Donation
                </Link>
              </li>
            </ul>


          </div>
          <div class="dropdown" style={{ float: "right", marginRight: "120px" }}>
            <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" data-toggle="dropdown">
              <i class="bi bi-file-person-fill"></i>
            </button>
            <ul class="dropdown-menu" style={{ marginRight: 50 }}>
              <li><Link className="btn text-black"
                aria-current="page"
                to="/home" >
                {admin}</Link></li>
              <li><Link className="btn text-black"
                to="/home"
                onClick={Logout}>
                Logout</Link></li>
            </ul>
          </div>
        </div>


      </nav>
    );
  }
  else {
    return (
      <nav className="navbar navbar-expand-lg sticky-top navbar-light bg-dark text-white">
        <div className="container-fluid py-2">
          <NavLink
            className="navbar-brand mx-auto fw-bold me-2 text-white"
            to="/home"
          >
            <b><i><span style={{ color: "white" }}>AWC</span></i></b>
          </NavLink>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <Link
                  className="nav-link active text-white"
                  aria-current="page"
                  to="/home"
                >
                  Home
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-white" to="/team">
                  Our Team
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-white" to="/about">
                  About
                </Link>
              </li>

              <li>
              </li>


              <li className="nav-item">
                <Link className="nav-link text-white" to="/contact">
                  Contact
                </Link>
              </li>
            </ul>

            <ul className="navbar-nav me-auto mb-2 mb-lg-0" style={{ float: "right", marginLeft: "500px" }}>
              <li className="nav-item dropdown">
                <Link to="/adminlogin" className="btn btn-outline-light">Admin Login</Link>&nbsp;&nbsp;
                <Link to="/donateus" className="btn btn-outline-light ">Donate Us</Link>
              </li>
            </ul>

          </div>

        </div>
      </nav>
    );
  }
}
